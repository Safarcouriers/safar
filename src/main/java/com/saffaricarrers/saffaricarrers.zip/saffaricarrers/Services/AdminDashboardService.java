package com.saffaricarrers.saffaricarrers.Services;

import com.saffaricarrers.saffaricarrers.Dtos.*;
import com.saffaricarrers.saffaricarrers.Entity.*;
import com.saffaricarrers.saffaricarrers.Entity.Package;
import com.saffaricarrers.saffaricarrers.Repository.*;
import com.saffaricarrers.saffaricarrers.Responses.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class AdminDashboardService {

    private final UserRepository userRepository;
    private final CarrierProfileRepository carrierProfileRepository;
    private final PackageRepository packageRepository;
    private final DeliveryRequestRepository deliveryRequestRepository;
    private final PaymentRepository paymentRepository;
    private final CarrierRouteRepository carrierRouteRepository;
    private final DocumentVerificationStatusRepository documentStatusRepository;

    // ==================== MAIN DASHBOARD STATS ====================

    public AdminDashboardResponse getDashboardStats() {
        AdminDashboardResponse response = new AdminDashboardResponse();

        // User Stats
        response.setUserStats(getUserStats());

        // Verification Stats
        response.setVerificationStats(getVerificationStats());

        // Package Stats
        response.setPackageStats(getPackageStats());

        // Delivery Request Stats
        response.setDeliveryStats(getDeliveryStats());

        // Revenue Stats
     //   response.setRevenueStats(getRevenueStats());

        // Commission Stats
        response.setCommissionStats(getCommissionStats());

        // Today's Overview
        response.setTodayOverview(getTodayOverview());

        response.setGeneratedAt(LocalDateTime.now());

        return response;
    }
    private DeliveryStatsDto getDeliveryStats() {
        DeliveryStatsDto stats = new DeliveryStatsDto();

        // Use count queries - NO N+1
        stats.setTotalRequests(deliveryRequestRepository.count());
        stats.setPendingRequests(deliveryRequestRepository.countByStatus(DeliveryRequest.RequestStatus.PENDING));
        stats.setAcceptedRequests(deliveryRequestRepository.countByStatus(DeliveryRequest.RequestStatus.ACCEPTED));
        stats.setPickedUpRequests(deliveryRequestRepository.countByStatus(DeliveryRequest.RequestStatus.PICKED_UP));
        stats.setInTransitRequests(deliveryRequestRepository.countByStatus(DeliveryRequest.RequestStatus.IN_TRANSIT));
        stats.setDeliveredRequests(deliveryRequestRepository.countByStatus(DeliveryRequest.RequestStatus.DELIVERED));
        stats.setRejectedRequests(deliveryRequestRepository.countByStatus(DeliveryRequest.RequestStatus.REJECTED));
        stats.setCancelledRequests(deliveryRequestRepository.countByStatus(DeliveryRequest.RequestStatus.CANCELLED));

        // Success rate
        double successRate = stats.getTotalRequests() > 0 ?
                (stats.getDeliveredRequests() * 100.0 / stats.getTotalRequests()) : 0.0;
        stats.setDeliverySuccessRate(Math.round(successRate * 100.0) / 100.0);

        // Use aggregation query
        Double averageAmount = deliveryRequestRepository.getAverageTotalAmount();
        stats.setAverageDeliveryAmount(averageAmount != null ? averageAmount : 0.0);

        return stats;
    }
    // ==================== USER STATISTICS ====================

    private CommissionStatsDto getCommissionStats() {
        CommissionStatsDto stats = new CommissionStatsDto();

        // This will now use @EntityGraph and load User + BankDetails in ONE query
        List<CarrierProfile> allCarriers = carrierProfileRepository.findAll();

        // All processing in memory - NO additional queries
        double totalPendingCommission = allCarriers.stream()
                .filter(c -> c.getPendingCommission() != null)
                .mapToDouble(c -> c.getPendingCommission().doubleValue())
                .sum();

        double totalEarnings = allCarriers.stream()
                .filter(c -> c.getTotalEarnings() != null)
                .mapToDouble(c -> c.getTotalEarnings().doubleValue())
                .sum();

        stats.setTotalPendingCommission(totalPendingCommission);
        stats.setTotalCarrierEarnings(totalEarnings);

        long carriersWithPending = allCarriers.stream()
                .filter(c -> c.getPendingCommission() != null &&
                        c.getPendingCommission().compareTo(BigDecimal.ZERO) > 0)
                .count();
        stats.setCarriersWithPendingCommission(carriersWithPending);

        // Daily commission
        double dailyCommission = getCommissionForDate(LocalDate.now());
        stats.setDailyCommission(dailyCommission);

        // Status counts
        long activeCarriers = allCarriers.stream()
                .filter(c -> c.getStatus() == CarrierProfile.CarrierStatus.ACTIVE)
                .count();
        long inactiveCarriers = allCarriers.stream()
                .filter(c -> c.getStatus() == CarrierProfile.CarrierStatus.INACTIVE)
                .count();
        long suspendedCarriers = allCarriers.stream()
                .filter(c -> c.getStatus() == CarrierProfile.CarrierStatus.SUSPENDED)
                .count();

        stats.setActiveCarriers(activeCarriers);
        stats.setInactiveCarriers(inactiveCarriers);
        stats.setSuspendedCarriers(suspendedCarriers);

        return stats;
    }

    // ==================== VERIFICATION STATISTICS ====================

    private VerificationStatsDto getVerificationStats() {
        List<DocumentVerificationStatus> allStatuses = documentStatusRepository.findAll();

        VerificationStatsDto stats = new VerificationStatsDto();

        // Count by status
        long verified = allStatuses.stream()
                .filter(s -> s.getStatus() == DocumentVerificationStatus.DocumentVerificationStatusEnum.DOCUMENT_VERIFIED)
                .count();
        long pending = allStatuses.stream()
                .filter(s -> s.getStatus() == DocumentVerificationStatus.DocumentVerificationStatusEnum.NOT_STARTED)
                .count();
        long rejected = allStatuses.stream()
                .filter(s -> s.getStatus() == DocumentVerificationStatus.DocumentVerificationStatusEnum.DOCUMENT_REJECTED)
                .count();

        stats.setTotalVerifications((long) allStatuses.size());
        stats.setVerifiedDocuments(verified);
        stats.setPendingVerifications(pending);
        stats.setRejectedDocuments(rejected);

        // Count by document type
        long aadhaarCount = allStatuses.stream()
                .filter(s -> s.getDocumentType() == OtpVerification.DocumentType.AADHAAR)
                .count();
        long panCount = allStatuses.stream()
                .filter(s -> s.getDocumentType() == OtpVerification.DocumentType.PAN)
                .count();

        stats.setAadhaarVerifications(aadhaarCount);
        stats.setPanVerifications(panCount);

        // Get users stuck at each verification stage
        stats.setUsersStuckAtVerification(getUsersStuckAtVerificationStages());

        return stats;
    }

    private Map<String, Long> getUsersStuckAtVerificationStages() {
        List<User> allUsers = userRepository.findAll();

        Map<String, Long> stuckUsers = new HashMap<>();

        // Users pending verification
        long pendingVerfication = allUsers.stream()
                .filter(u -> u.getVerificationStatus() == User.VerificationStatus.PENDING)
                .count();

        // Users rejected
        long rejectedUsers = allUsers.stream()
                .filter(u -> u.getVerificationStatus() == User.VerificationStatus.REJECTED)
                .count();

        // Users verified but profile incomplete
        long verifiedButIncomplete = allUsers.stream()
                .filter(u -> u.getVerified() &&
                        (u.getProfileUrl() == null ||
                                u.getAadharFrontUrl() == null ||
                                u.getAadharBackUrl() == null ||
                                u.getPanCardUrl() == null))
                .count();

        stuckUsers.put("PENDING_VERIFICATION", pendingVerfication);
        stuckUsers.put("REJECTED", rejectedUsers);
        stuckUsers.put("VERIFIED_INCOMPLETE_PROFILE", verifiedButIncomplete);

        return stuckUsers;
    }

    // ==================== PACKAGE STATISTICS ====================

    private PackageStatsDto1 getPackageStats() {
        List<Package> allPackages = packageRepository.findAll();

        PackageStatsDto1 stats = new PackageStatsDto1();
        stats.setTotalPackages((long) allPackages.size());

        // Count by status
        Map<String, Long> statusCount = allPackages.stream()
                .collect(Collectors.groupingBy(
                        pkg -> pkg.getStatus().name(),
                        Collectors.counting()
                ));

        stats.setCreatedPackages(statusCount.getOrDefault("CREATED", 0L));
        stats.setRequestSentPackages(statusCount.getOrDefault("REQUEST_SENT", 0L));
        stats.setMatchedPackages(statusCount.getOrDefault("MATCHED", 0L));
        stats.setPickedUpPackages(statusCount.getOrDefault("PICKED_UP", 0L));
        stats.setInTransitPackages(statusCount.getOrDefault("IN_TRANSIT", 0L));
        stats.setDeliveredPackages(statusCount.getOrDefault("DELIVERED", 0L));
        stats.setCancelledPackages(statusCount.getOrDefault("CANCELLED", 0L));

        // Count by product type
        Map<String, Long> productTypeCount = allPackages.stream()
                .collect(Collectors.groupingBy(
                        pkg -> pkg.getProductType().name(),
                        Collectors.counting()
                ));
        stats.setProductTypeBreakdown(productTypeCount);

        // Count by transport type
        Map<String, Long> transportTypeCount = allPackages.stream()
                .collect(Collectors.groupingBy(
                        pkg -> pkg.getTransportType().name(),
                        Collectors.counting()
                ));
        stats.setTransportTypeBreakdown(transportTypeCount);

        // Insurance stats
        long insuredPackages = allPackages.stream()
                .filter(Package::getInsurance)
                .count();
        stats.setInsuredPackages(insuredPackages);
        stats.setUninsuredPackages(stats.getTotalPackages() - insuredPackages);

        // Total value
        double totalValue = allPackages.stream()
                .filter(pkg -> pkg.getProductValue() != null)
                .mapToDouble(pkg -> pkg.getProductValue().doubleValue())
                .sum();
        stats.setTotalPackageValue(totalValue);

        return stats;
    }

    // ==================== DELIVERY REQUEST STATISTICS ====================


    // ==================== REVENUE & COMMISSION STATISTICS ====================

//    private RevenueStatsDto getRevenueStats() {
//        List<Payment> allPayments = paymentRepository.findAll();
//
//        RevenueStatsDto stats = new RevenueStatsDto();
//
//        // Count by payment status
//        long completedPayments = allPayments.stream()
//                .filter(p -> p.getPaymentStatus() == Payment.PaymentStatus.COMPLETED)
//                .count();
//        long pendingPayments = allPayments.stream()
//                .filter(p -> p.getPaymentStatus() == Payment.PaymentStatus.PENDING)
//                .count();
//        long failedPayments = allPayments.stream()
//                .filter(p -> p.getPaymentStatus() == Payment.PaymentStatus.FAILED)
//                .count();
//
//        stats.setTotalPayments((long) allPayments.size());
//        stats.setCompletedPayments(completedPayments);
//        stats.setPendingPayments(pendingPayments);
//        stats.setFailedPayments(failedPayments);
//
//        // Count by payment method
//        long onlinePayments = allPayments.stream()
//                .filter(p -> p.getPaymentMethod() == Payment.PaymentMethod.ONLINE)
//                .count();
//        long codPayments = allPayments.stream()
//                .filter(p -> p.getPaymentMethod() == Payment.PaymentMethod.COD)
//                .count();
//
//        stats.setOnlinePayments(onlinePayments);
//        stats.setCodePayments(codPayments);
//
//        // Total revenue calculations
//        List<Payment> completedPaymentsList = allPayments.stream()
//                .filter(p -> p.getPaymentStatus() == Payment.PaymentStatus.COMPLETED)
//                .collect(Collectors.toList());
//
//        double totalRevenue = completedPaymentsList.stream()
//                .filter(p -> p.getTotalAmount() != null)
//                .mapToDouble(p -> p.getTotalAmount().doubleValue())
//                .sum();
//
//        double totalCommission = completedPaymentsList.stream()
//                .filter(p -> p.getPlatformCommission() != null)
//                .mapToDouble(p -> p.getPlatformCommission().doubleValue())
//                .sum();
//
//        double totalCarrierPayouts = completedPaymentsList.stream()
//                .filter(p -> p.getCarrierAmount() != null)
//                .mapToDouble(p -> p.getCarrierAmount().doubleValue())
//                .sum();
//
//        double totalInsurance = completedPaymentsList.stream()
//                .filter(p -> p.getInsuranceAmount() != null)
//                .mapToDouble(p -> p.getInsuranceAmount().doubleValue())
//                .sum();
//
//        stats.setTotalRevenue(totalRevenue);
//        stats.setTotalCommission(totalCommission);
//        stats.setTotalCarrierPayouts(totalCarrierPayouts);
//        stats.setTotalInsuranceCollected(totalInsurance);
//
//        // Daily average
//        long daysActive = 30;
//        stats.setDailyAverageRevenue(totalRevenue / daysActive);
//
//        return stats;
//    }

//    private CommissionStatsDto getCommissionStats() {
//        List<CarrierProfile> allCarriers = carrierProfileRepository.findAll();
//
//        CommissionStatsDto stats = new CommissionStatsDto();
//
//        // Total pending commission
//        double totalPendingCommission = allCarriers.stream()
//                .filter(c -> c.getPendingCommission() != null)
//                .mapToDouble(c -> c.getPendingCommission().doubleValue())
//                .sum();
//
//        // Total earnings
//        double totalEarnings = allCarriers.stream()
//                .filter(c -> c.getTotalEarnings() != null)
//                .mapToDouble(c -> c.getTotalEarnings().doubleValue())
//                .sum();
//
//        stats.setTotalPendingCommission(totalPendingCommission);
//        stats.setTotalCarrierEarnings(totalEarnings);
//
//        // Carriers with pending commission
//        long carriersWithPending = allCarriers.stream()
//                .filter(c -> c.getPendingCommission() != null &&
//                        c.getPendingCommission().compareTo(BigDecimal.ZERO) > 0)
//                .count();
//        stats.setCarriersWithPendingCommission(carriersWithPending);
//
//        // Daily commission (today)
//        double dailyCommission = getCommissionForDate(LocalDate.now());
//        stats.setDailyCommission(dailyCommission);
//
//        // Commission by status
//        long activeCarriers = allCarriers.stream()
//                .filter(c -> c.getStatus() == CarrierProfile.CarrierStatus.ACTIVE)
//                .count();
//        long inactiveCarriers = allCarriers.stream()
//                .filter(c -> c.getStatus() == CarrierProfile.CarrierStatus.INACTIVE)
//                .count();
//        long suspendedCarriers = allCarriers.stream()
//                .filter(c -> c.getStatus() == CarrierProfile.CarrierStatus.SUSPENDED)
//                .count();
//
//        stats.setActiveCarriers(activeCarriers);
//        stats.setInactiveCarriers(inactiveCarriers);
//        stats.setSuspendedCarriers(suspendedCarriers);
//
//        return stats;
//    }

    // ==================== TODAY'S OVERVIEW ====================

    private TodayOverviewDto getTodayOverview() {
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = today.atTime(23, 59, 59);

        TodayOverviewDto overview = new TodayOverviewDto();

        // Today's packages
        long packagesCreated = packageRepository.findAll().stream()
                .filter(p -> p.getCreatedAt() != null &&
                        p.getCreatedAt().isAfter(startOfDay) &&
                        p.getCreatedAt().isBefore(endOfDay))
                .count();
        overview.setPackagesCreatedToday(packagesCreated);

        // Today's delivery requests
        long requestsCreated = deliveryRequestRepository.findAll().stream()
                .filter(r -> r.getRequestedAt() != null &&
                        r.getRequestedAt().isAfter(startOfDay) &&
                        r.getRequestedAt().isBefore(endOfDay))
                .count();
        overview.setRequestsCreatedToday(requestsCreated);

        // Today's deliveries completed
        long deliveriesCompleted = deliveryRequestRepository.findAll().stream()
                .filter(r -> r.getStatus() == DeliveryRequest.RequestStatus.DELIVERED &&
                        r.getDeliveredAt() != null &&
                        r.getDeliveredAt().isAfter(startOfDay) &&
                        r.getDeliveredAt().isBefore(endOfDay))
                .count();
        overview.setDeliveriesCompletedToday(deliveriesCompleted);

        // Today's revenue
        double todayRevenue = paymentRepository.findAll().stream()
                .filter(p -> p.getPaymentStatus() == Payment.PaymentStatus.COMPLETED &&
                        p.getPaymentCompletedAt() != null &&
                        p.getPaymentCompletedAt().isAfter(startOfDay) &&
                        p.getPaymentCompletedAt().isBefore(endOfDay) &&
                        p.getTotalAmount() != null)
                .mapToDouble(p -> p.getTotalAmount().doubleValue())
                .sum();
        overview.setRevenueToday(todayRevenue);

        // Today's commission
        overview.setCommissionToday(getCommissionForDate(today));

        // New users today
        long newUsersToday = userRepository.findAll().stream()
                .filter(u -> u.getCreatedAt() != null &&
                        u.getCreatedAt().isAfter(startOfDay) &&
                        u.getCreatedAt().isBefore(endOfDay))
                .count();
        overview.setNewUsersToday(newUsersToday);

        // Active trips today
        long activeTripToday = carrierRouteRepository.findAll().stream()
                .filter(r -> r.getRouteStatus() == CarrierRoute.RouteStatus.ACTIVE &&
                        r.getAvailableDate() != null &&
                        r.getAvailableDate().isEqual(today))
                .count();
        overview.setActiveTripsToday(activeTripToday);

        return overview;
    }

    // ==================== DAY-WISE ANALYTICS ====================

    public DayWiseAnalyticsResponse getDayWiseAnalytics(int days) {
        DayWiseAnalyticsResponse response = new DayWiseAnalyticsResponse();
        List<DayAnalyticsDto> dayAnalytics = new ArrayList<>();

        for (int i = days - 1; i >= 0; i--) {
            LocalDate date = LocalDate.now().minusDays(i);
            DayAnalyticsDto dayData = new DayAnalyticsDto();

            dayData.setDate(date);
            dayData.setPackagesCreated(countPackagesForDate(date));
            dayData.setDeliveriesCompleted(countDeliveriesForDate(date));
            dayData.setRevenue(getRevenueForDate(date));
            dayData.setCommission(getCommissionForDate(date));
            dayData.setNewUsers(countNewUsersForDate(date));
            dayData.setRequestsCreated(countRequestsForDate(date));

            dayAnalytics.add(dayData);
        }

        response.setDayWiseData(dayAnalytics);
        response.setGeneratedAt(LocalDateTime.now());

        return response;
    }

    // ==================== DETAILED LISTS ====================

    public PendingDeliveriesResponse getPendingDeliveries() {
        List<DeliveryRequest> pendingRequests = deliveryRequestRepository.findAll().stream()
                .filter(r -> r.getStatus() == DeliveryRequest.RequestStatus.PENDING)
                .collect(Collectors.toList());

        List<DeliveryRequestDetailDto> details = pendingRequests.stream()
                .map(this::mapToDeliveryDetail)
                .collect(Collectors.toList());

        return new PendingDeliveriesResponse(
                (long) details.size(),
                details
        );
    }

    public CompletedDeliveriesResponse getCompletedDeliveries() {
        List<DeliveryRequest> completedRequests = deliveryRequestRepository.findAll().stream()
                .filter(r -> r.getStatus() == DeliveryRequest.RequestStatus.DELIVERED)
                .collect(Collectors.toList());

        List<DeliveryRequestDetailDto> details = completedRequests.stream()
                .map(this::mapToDeliveryDetail)
                .collect(Collectors.toList());

        return new CompletedDeliveriesResponse(
                (long) details.size(),
                details
        );
    }

    public UserListResponse getUnverifiedUsers() {
        List<User> unverifiedUsers = userRepository.findAll().stream()
                .filter(u -> !u.getVerified())
                .collect(Collectors.toList());

        List<UserDetailDto> details = unverifiedUsers.stream()
                .map(this::mapToUserDetail)
                .collect(Collectors.toList());

        return new UserListResponse(
                (long) details.size(),
                details
        );
    }

    public UserListResponse getVerifiedUsers() {
        List<User> verifiedUsers = userRepository.findAll().stream()
                .filter(User::getVerified)
                .collect(Collectors.toList());

        List<UserDetailDto> details = verifiedUsers.stream()
                .map(this::mapToUserDetail)
                .collect(Collectors.toList());

        return new UserListResponse(
                (long) details.size(),
                details
        );
    }

    // ==================== HELPER METHODS ====================

    private long countPackagesForDate(LocalDate date) {
        return packageRepository.findAll().stream()
                .filter(p -> p.getCreatedAt() != null &&
                        p.getCreatedAt().toLocalDate().isEqual(date))
                .count();
    }

    private long countDeliveriesForDate(LocalDate date) {
        return deliveryRequestRepository.findAll().stream()
                .filter(r -> r.getStatus() == DeliveryRequest.RequestStatus.DELIVERED &&
                        r.getDeliveredAt() != null &&
                        r.getDeliveredAt().toLocalDate().isEqual(date))
                .count();
    }

    private double getRevenueForDate(LocalDate date) {
        return paymentRepository.findAll().stream()
                .filter(p -> p.getPaymentStatus() == Payment.PaymentStatus.COMPLETED &&
                        p.getPaymentCompletedAt() != null &&
                        p.getPaymentCompletedAt().toLocalDate().isEqual(date) &&
                        p.getTotalAmount() != null)
                .mapToDouble(p -> p.getTotalAmount().doubleValue())
                .sum();
    }

    private double getCommissionForDate(LocalDate date) {
        return paymentRepository.findAll().stream()
                .filter(p -> p.getPaymentStatus() == Payment.PaymentStatus.COMPLETED &&
                        p.getPaymentCompletedAt() != null &&
                        p.getPaymentCompletedAt().toLocalDate().isEqual(date) &&
                        p.getPlatformCommission() != null)
                .mapToDouble(p -> p.getPlatformCommission().doubleValue())
                .sum();
    }

    private long countRequestsForDate(LocalDate date) {
        return deliveryRequestRepository.findAll().stream()
                .filter(r -> r.getRequestedAt() != null &&
                        r.getRequestedAt().toLocalDate().isEqual(date))
                .count();
    }

    private long countNewUsersForDate(LocalDate date) {
        return userRepository.findAll().stream()
                .filter(u -> u.getCreatedAt() != null &&
                        u.getCreatedAt().toLocalDate().isEqual(date))
                .count();
    }

    private DeliveryRequestDetailDto mapToDeliveryDetail(DeliveryRequest request) {
        return DeliveryRequestDetailDto.builder()
                .requestId(request.getRequestId())
                .packageName(request.getPackageEntity() != null ?
                        request.getPackageEntity().getProductName() : "N/A")
                .senderName(request.getSender() != null ?
                        request.getSender().getFullName() : "N/A")
                .carrierName(request.getCarrier() != null ?
                        request.getCarrier().getFullName() : "N/A")
                .fromAddress(request.getPackageEntity() != null ?
                        request.getPackageEntity().getFromAddress() : "N/A")
                .toAddress(request.getPackageEntity() != null ?
                        request.getPackageEntity().getToAddress() : "N/A")
                .amount(request.getTotalAmount() != null ?
                        request.getTotalAmount().doubleValue() : 0.0)
                .status(request.getStatus())
                .requestedAt(request.getRequestedAt())
                .deliveredAt(request.getDeliveredAt())
                .build();
    }

    private UserDetailDto mapToUserDetail(User user) {
        return UserDetailDto.builder()
                .userId(user.getUserId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .mobile(user.getMobile())
                .userType(user.getUserType())
                .verified(user.getVerified())
                .verificationStatus(user.getVerificationStatus())
                .status(user.getStatus())
                .createdAt(user.getCreatedAt())
                .profileUrl(user.getProfileUrl())
                .build();
    }
    private UserStatsDto getUserStats() {
        // This will now use @EntityGraph and load CarrierProfile + BankDetails
        List<User> allUsers = userRepository.findAll();

        UserStatsDto stats = new UserStatsDto();
        stats.setTotalUsers((long) allUsers.size());

        // All processing in memory
        long senders = allUsers.stream()
                .filter(u -> u.getUserType() == User.UserType.SENDER)
                .count();
        long carriers = allUsers.stream()
                .filter(u -> u.getUserType() == User.UserType.CARRIER)
                .count();
        long both = allUsers.stream()
                .filter(u -> u.getUserType() == User.UserType.BOTH)
                .count();

        stats.setSenderUsers(senders);
        stats.setCarrierUsers(carriers);
        stats.setBothUsers(both);

        long verified = allUsers.stream()
                .filter(User::getVerified)
                .count();
        stats.setVerifiedUsers(verified);
        stats.setUnverifiedUsers(stats.getTotalUsers() - verified);

        long active = allUsers.stream()
                .filter(u -> u.getStatus() == User.UserStatus.ACTIVE)
                .count();
        stats.setActiveUsers(active);
        stats.setInactiveUsers(stats.getTotalUsers() - active);

        Map<String, Long> genderCount = allUsers.stream()
                .collect(Collectors.groupingBy(
                        u -> u.getGender() != null ? u.getGender().name() : "UNKNOWN",
                        Collectors.counting()
                ));
        stats.setGenderBreakdown(genderCount);

        return stats;
    }

//    // ✅ OPTIMIZED: Use aggregation queries
//    private RevenueStatsDto getRevenueStats() {
//        RevenueStatsDto stats = new RevenueStatsDto();
//
//        // Use count queries instead of loading all
//        stats.setTotalPayments(paymentRepository.count());
//        stats.setCompletedPayments(paymentRepository.countByPaymentStatus(Payment.PaymentStatus.COMPLETED));
//        stats.setPendingPayments(paymentRepository.countByPaymentStatus(Payment.PaymentStatus.PENDING));
//        stats.setFailedPayments(paymentRepository.countByPaymentStatus(Payment.PaymentStatus.FAILED));
//
//        // Count by method
//        long onlinePayments = paymentRepository.countByPaymentMethod(Payment.PaymentMethod.ONLINE);
//        long codPayments = paymentRepository.countByPaymentMethod(Payment.PaymentMethod.COD);
//
//        stats.setOnlinePayments(onlinePayments);
//        stats.setCodePayments(codPayments);
//
//        // Use aggregation queries
//        Double totalRevenue = paymentRepository.sumTotalAmountByStatus(Payment.PaymentStatus.COMPLETED);
//        Double totalCommission = paymentRepository.sumPlatformCommissionByStatus(Payment.PaymentStatus.COMPLETED);
//        Double totalCarrierPayouts = paymentRepository.sumCarrierAmountByStatus(Payment.PaymentStatus.COMPLETED);
//        Double totalInsurance = paymentRepository.sumInsuranceAmountByStatus(Payment.PaymentStatus.COMPLETED);
//
//        stats.setTotalRevenue(totalRevenue != null ? totalRevenue : 0.0);
//        stats.setTotalCommission(totalCommission != null ? totalCommission : 0.0);
//        stats.setTotalCarrierPayouts(totalCarrierPayouts != null ? totalCarrierPayouts : 0.0);
//        stats.setTotalInsuranceCollected(totalInsurance != null ? totalInsurance : 0.0);
//
//        // Daily average
//        long daysActive = 30;
//        stats.setDailyAverageRevenue(stats.getTotalRevenue() / daysActive);
//
//        return stats;
//    }

}
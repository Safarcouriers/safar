package com.saffaricarrers.saffaricarrers.Repository;

import com.saffaricarrers.saffaricarrers.Entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, String> {
    Optional<User> findByEmail(String email);
    Optional<User> findByMobile(String mobile);
    boolean existsByEmail(String email);
    boolean existsByMobile(String mobile);
    boolean existsByUserId(String userId);

    @EntityGraph(value = "User.basic", type = EntityGraph.EntityGraphType.LOAD)
    Optional<User> findByUserId(String uid);

    @EntityGraph(value = "User.withCarrierProfile", type = EntityGraph.EntityGraphType.LOAD)
    @Override
    List<User> findAll();

    @EntityGraph(value = "User.withCarrierProfile", type = EntityGraph.EntityGraphType.LOAD)
    @Query("SELECT u FROM User u WHERE u.userId = :userId")
    Optional<User> findByUserIdWithProfile(@Param("userId") String userId);

    // ✅ FIXED — removed LEFT JOIN FETCH cp.bankDetails
    @Query(value = "SELECT DISTINCT u FROM User u LEFT JOIN FETCH u.carrierProfile cp",
            countQuery = "SELECT COUNT(DISTINCT u) FROM User u")
    Page<User> findAllWithCarrierProfile(Pageable pageable);

    Page<User> findAll(Pageable pageable);

    // ✅ NEW — direct FCM update, zero joins
    @Modifying
    @Transactional
    @Query("UPDATE User u SET u.FcmToken = :token WHERE u.userId = :userId")
    int updateFcmTokenDirectly(
            @Param("userId") String userId,
            @Param("token") String token
    );

}
